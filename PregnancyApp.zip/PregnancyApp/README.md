YouTube tutorial how to create a checkbox by subclassing UIButton
Can be viewed here: https://youtu.be/ajlkFFPxW_c

V3.0 Updated to swift 4.1 example code.

V2.0 Added ability to set the checkbox as checked or not via Interface Builder. 
Using the @IBInspectable property.
Also cleaned up code a bit.

V1.0 As Shown on youtube.
