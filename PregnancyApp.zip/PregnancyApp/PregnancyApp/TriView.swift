//
//  TriView.swift
//  UniApp
//
//  Created by Veton Jonuzi
//  Copyright © 2022 Veton. All rights reserved.
//

import UIKit

class TriView: UIViewController {

    
    @IBOutlet weak var triButton1: UIButton!
    
    @IBOutlet weak var triButton2: UIButton!
    
    @IBOutlet weak var triButton3: UIButton!
    
     let yourAttributes1: [NSAttributedString.Key: Any] = [
          .font: UIFont.boldSystemFont(ofSize: 20),
          .foregroundColor: UIColor.black,
          .underlineStyle: NSUnderlineStyle.single.rawValue
      ]
    let yourAttributes2: [NSAttributedString.Key: Any] = [
          .font: UIFont.boldSystemFont(ofSize: 20),
          .foregroundColor: UIColor.black,
          .underlineStyle: NSUnderlineStyle.single.rawValue
      ]
    let yourAttributes3: [NSAttributedString.Key: Any] = [
          .font: UIFont.boldSystemFont(ofSize: 20),
          .foregroundColor: UIColor.black,
          .underlineStyle: NSUnderlineStyle.single.rawValue
      ]
    
    override func viewDidLoad() {
        super.viewDidLoad()
        

        let attributeString1 = NSMutableAttributedString(
                string: "Weeks 1 - 12",
                attributes: yourAttributes1
             )
             triButton1.setAttributedTitle(attributeString1, for: .normal)
        let attributeString2 = NSMutableAttributedString(
                string: "Weeks 13-26",
                attributes: yourAttributes2
             )
             triButton2.setAttributedTitle(attributeString2, for: .normal)
        let attributeString3 = NSMutableAttributedString(
                string: "Weeks 27-40 or end of pregnancy",
                attributes: yourAttributes3
             )
             triButton3.setAttributedTitle(attributeString3, for: .normal) 
    }
}
