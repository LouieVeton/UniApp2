//
//  CheckBox.swift
//  checkbox
//
//  Created by Veton
//
//



import UIKit

class CheckBox: UIButton {
    
    //images
    let checkedImage = UIImage(named: "checkedd_checkbox")
    let unCheckedImage = UIImage(named: "uncheckedd_checkbox")
    
    
    //bool propety
    @IBInspectable var isChecked:Bool = false{
        didSet{
            self.updateImage()
        }
    }

    
    override func awakeFromNib() {
       self.addTarget(self, action: #selector(CheckBox.buttonClicked), for: UIControl.Event.touchUpInside)
       isChecked = UserDefaults.standard.bool(forKey: String(self.tag))
       self.imageView?.contentMode = .scaleAspectFit
       self.updateImage()
    }
    
    
    func updateImage() {
        if isChecked == true{
            self.setImage(checkedImage, for: [])
        }else{
            self.setImage(unCheckedImage, for: [])
        }

    }

    @objc func buttonClicked(sender:UIButton) {
        if(sender == self){
            isChecked = !isChecked
            UserDefaults.standard.set(isChecked, forKey: String(sender.tag))
            print(sender.tag)
        }
    }

}
