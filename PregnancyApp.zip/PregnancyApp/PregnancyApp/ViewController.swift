//
//  ViewController.swift
//  Checkbox
//
//  Created by Veton
//  Copyright © 2022 Veton Jonuzi. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    @IBOutlet weak var todaysDate: UILabel!
    
    @IBOutlet weak var link1: UITextView!
    
    @IBOutlet weak var link2: UITextView!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        updateTextView()
        updateTextView2()
        
        let date = Date()
        
        let formatter = DateFormatter()
        formatter.timeZone = .current
        formatter.locale = .current
        formatter.dateFormat = "EEEE, d MMMM"
        
        todaysDate.text = formatter.string(from: date)
        todaysDate.numberOfLines = 0
        todaysDate.sizeToFit()
        todaysDate.adjustsFontSizeToFitWidth = true
        todaysDate.minimumScaleFactor = 0.5
        
        func updateTextView() {
            let path = "https://www.beyondblue.org.au"
            let text = link1.text ?? ""
            let attributedSting = NSAttributedString.makeHyperlink(for: path, in: text, as: "Beyond Blue")
            let font = link1.font
            let textColor = link1.textColor
            link1.attributedText = attributedSting
            link1.font = font
            link1.textColor = textColor
        }
        
        func updateTextView2() {
            let path = "https://www.healthdirect.gov.au/nurse-on-call"
            let text = link2.text ?? ""
            let attributedSting = NSAttributedString.makeHyperlink(for: path, in: text, as: "Nurse on Call")
            let font = link2.font
            let textColor = link2.textColor
            link2.attributedText = attributedSting
            link2.font = font
            link2.textColor = textColor
        }
        
        
        //check if its first time app open
        // Gets user pregnancy days
        // store value if firsttime == false change to true
        // if true
        // Put in the firs date,
        // compare today date to the first date this app opened
        // get the amount of date passed from the app first opened + the pregnancy days user entered when the user first opened
        
    }
    
}
